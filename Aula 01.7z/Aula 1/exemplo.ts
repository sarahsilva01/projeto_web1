let saudacao: string
saudacao = "Boa noite"
let nome: string
nome = "João"

console.log(`uma mensagem legal ${saudacao}, ${nome}!`)