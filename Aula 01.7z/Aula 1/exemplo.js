var saudacao;
saudacao = "Boa noite";
var nome;
nome = "João";
console.log("uma mensagem legal ".concat(saudacao, ", ").concat(nome, "!"));
